package web;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cashier;
import database.CashierData;
@WebServlet("/register1")
public class CashierServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private CashierData CashierData;
  int i=0;
    public void init() {
    	CashierData = new CashierData();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    	response.setContentType("text/html;charset=UTF-8");
    	PrintWriter out=response.getWriter();
        String first_name = request.getParameter("first_name");
        String last_name = request.getParameter("last_name");
        String address = request.getParameter("address");
        String contact = request.getParameter("contact");
        String password = request.getParameter("password");
        String userid = request.getParameter("userid");
        String age = request.getParameter("age");
        String gender = request.getParameter("gender");
        String question = request.getParameter("question");
        String answer = request.getParameter("answer");
        if(first_name.equalsIgnoreCase("null") || last_name.equalsIgnoreCase("null") || userid.equalsIgnoreCase("null") ||address.equalsIgnoreCase("null"))
        {
        	
        	out.println("<script type=\"text/javascript\">");
        	out.println("alert('Fields Cannot be Null');");
        	out.println("location='CashierRegistrarion.jsp';");
        	out.println("</script>");
        	
        }
      
        else
        {
       cashier k = new cashier();
       k.setFirst_name(first_name);
       k.setLast_name(last_name);
        k.setAddress(address);
        k.setContact(contact);
       k.setPassword(password);
       k.setUserid(userid);
       k.setAge(age);
       k.setGender(gender);
       k.setQuestion(question);
       k.setAnswer(answer);
       try {
           i=CashierData.Cashier(k);
       } catch (Exception e) {
           // TODO Auto-generated catch block
           e.printStackTrace();
       }
       if(i==0)
       {
        out.println("<script type=\"text/javascript\">");
           out.println("alert('Registration Unsuccessful/Email already exists');");
           out.println("location='UserRegistration.jsp';");
           out.println("</script>");
       }
       else
       {
           response.sendRedirect("CashierDetails.jsp");
       }

   }
   }
}
