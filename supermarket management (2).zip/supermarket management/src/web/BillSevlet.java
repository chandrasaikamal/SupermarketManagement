package web;
import java.io.IOException;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/BillServlet")
public class BillSevlet extends HttpServlet {
	static int sum=0;
@Override
protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	String category=req.getParameter("category");
	String quantity=req.getParameter("quantity");
	try
	{
	Class.forName("com.mysql.jdbc.Driver");    
	Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3305/project", "root", "Kamal@1998");
	PreparedStatement pst2 = con.prepareStatement("select price from inventory where category='"+category+"'");
	ResultSet rs1 = pst2.executeQuery();
	String value="";
	int bill=0;
	int n=5;
	HttpSession hs=req.getSession();
	while(rs1.next())
	{
		value=(rs1.getString(1));
		bill=Integer.parseInt((quantity))*Integer.parseInt((value));	
		//hs.isNew();
		
	  	if(hs.isNew())
		sum=(Integer)hs.getAttribute("s");
		sum=sum+bill;
		System.out.println("Total :" +sum);
	}
	//HttpSession hs=req.getSession();
	hs.setAttribute("s",sum);
}
	catch (Exception e) {
        // TODO Auto-generated catch block
        e.printStackTrace();
}
}
}

