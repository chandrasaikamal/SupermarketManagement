	package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.user;
public class USerData {

    private static final String INSERT_USERS_SQL = null;
	private Connection connection;
	public int registerUser(user us) throws ClassNotFoundException {
		System.out.println("hiii");
        String INSERT_USERS_SQL = "INSERT IGNORE INTO manager_details(id,firstname,lastname,age,gender,contact,managerid,password,question,answer) values(?,?,?,?,?,?,?,?,?,?)";

        int result = 0;
        int count=0;
        Class.forName("com.mysql.jdbc.Driver");
System.out.println("welcome");
try {Connection connection = DriverManager
.getConnection("jdbc:mysql://localhost:3305/project", "root", "Kamal@1998");
PreparedStatement pst1 = connection.prepareStatement("select max(id)+1 from manager_details");
ResultSet rs = pst1.executeQuery();
int id=0;
while(rs.next())
{
id = rs.getInt(1);
}
            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL);
            preparedStatement.setInt(1, id);
            preparedStatement.setString(2, us.getFirstName());
            preparedStatement.setString(3,us.getLastName());
            preparedStatement.setString(4, us.getAge());
            preparedStatement.setString(5,us.getGender());
            preparedStatement.setString(6,us.getContact());
            preparedStatement.setString(7,us.getManagerid());
            preparedStatement.setString(8,us.getPassword());
            preparedStatement.setString(9,us.getQuestion());
            preparedStatement.setString(10,us.getAnswer());
            System.out.println(preparedStatement);
            
            // Step 3: Execute the query or update query
            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            // process sql exception
            printSQLException(e);
        }
        return result;
	}
	private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
