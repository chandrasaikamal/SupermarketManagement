package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cashier;
public class CashierData {

    private static final String INSERT_USERS_SQL1 = null;
	private Connection connection;
	public int Cashier(cashier ca) throws ClassNotFoundException {
        String INSERT_USERS_SQL1 = "INSERT INTO cashier_details VALUES ( ?, ?, ?, ?,?,?,?,?,?,?,?,?)";

        int result = 0;
        int count=0;
        Class.forName("com.mysql.jdbc.Driver");

        try {Connection connection = DriverManager
            .getConnection("jdbc:mysql://localhost:3305/project", "root", "Kamal@1998");
        PreparedStatement pst1 = connection.prepareStatement("select max(id)+1 from cashier_details");
        ResultSet rs = pst1.executeQuery();
        int id=0;
        while(rs.next())
        {
            id = rs.getInt(1);
        }

            // Step 2:Create a statement using connection object
            PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL1);
            preparedStatement.setInt(1, id);
            preparedStatement.setString(2, ca.getFirst_name());
            preparedStatement.setString(3,ca.getLast_name());
            preparedStatement.setString(4, ca.getAddress());
            preparedStatement.setString(5, ca.getContact());
            preparedStatement.setString(6,ca.getPassword());
            preparedStatement.setString(7,"No");
            preparedStatement.setString(8,ca.getUserid());
            preparedStatement.setString(9,ca.getAge());
            preparedStatement.setString(10,ca.getGender());
            preparedStatement.setString(11,ca.getQuestion());
            preparedStatement.setString(12,ca.getAnswer());
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            result = preparedStatement.executeUpdate();

        } catch (SQLException e) {
            // process sql exception
            printSQLException(e);
        }
        return result;
	}
	private void printSQLException(SQLException ex) {
        for (Throwable e: ex) {
            if (e instanceof SQLException) {
                e.printStackTrace(System.err);
                System.err.println("SQLState: " + ((SQLException) e).getSQLState());
                System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
                System.err.println("Message: " + e.getMessage());
                Throwable t = ex.getCause();
                while (t != null) {
                    System.out.println("Cause: " + t);
                    t = t.getCause();
                }
            }
        }
    }
}
